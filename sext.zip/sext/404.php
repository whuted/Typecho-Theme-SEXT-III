<?php $this->need('header.php'); ?>

		    <article class="content">
        <section class="post">
<p>Nothing Found. But you still can have a <a href="/">Look Around</a>.</p>
Here are some random posts and just take a look!
<hr>


<center><?php RandomArticleList::parse(); ?></center>
<hr>


</section>

        </article>
      </div>
    </div> <!--! end of #container -->
  </body>
</html>
